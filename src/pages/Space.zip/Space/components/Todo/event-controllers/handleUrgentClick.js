const handleUrgentClick = (setIsUrgent, isUrgent) => {
  setIsUrgent(!isUrgent);
};

export default handleUrgentClick;
