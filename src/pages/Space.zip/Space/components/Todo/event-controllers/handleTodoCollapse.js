const handleTodoCollapse = (isOpen, setIsOpen) => {
  setIsOpen(!isOpen);
};

export default handleTodoCollapse;
