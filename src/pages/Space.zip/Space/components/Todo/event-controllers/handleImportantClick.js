const handleImportantClick = (setIsImportant, isImportant) => {
  setIsImportant(!isImportant);
};

export default handleImportantClick;
