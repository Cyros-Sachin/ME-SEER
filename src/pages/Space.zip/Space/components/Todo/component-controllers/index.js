import TodoItem from "../../TodoItem/todo-item";

export default {
  TodoItem,
};
