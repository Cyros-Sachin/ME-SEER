// src/components/notepad-item/event-controller/handleHoverEnd.js

const handleHoverEnd = (setIsHovered) => {
  setIsHovered(false);
};

export default handleHoverEnd;
