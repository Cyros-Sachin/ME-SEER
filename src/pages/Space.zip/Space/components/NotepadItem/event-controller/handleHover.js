// src/components/notepad-item/event-controller/handleHover.js

const handleHover = (setIsHovered) => {
  setIsHovered(true);
};

export default handleHover;
