import { TodoContext } from "../../../contexts/todos-context";

const contextController = {
  TodoContext,
};

export default contextController;
