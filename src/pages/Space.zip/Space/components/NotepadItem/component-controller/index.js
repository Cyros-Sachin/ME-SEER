import BasicBlock from "../../basic-block/basic-block";

const componentController = {
  BasicBlock,
};

export default componentController;
