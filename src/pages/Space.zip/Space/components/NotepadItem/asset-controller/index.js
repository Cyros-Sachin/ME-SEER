import drag from "../assets/drag.png";
import plus from "../assets/Plus.png";
import dot from "../assets/DotOutline.png";

const assetControllers = {
  drag,
  plus,
  dot,
};

export default assetControllers;
