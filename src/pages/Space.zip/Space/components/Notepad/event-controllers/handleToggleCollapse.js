const handleToggleCollapse = (isOpen, setIsOpen) => {
  setIsOpen(!isOpen);
};

export default handleToggleCollapse;
