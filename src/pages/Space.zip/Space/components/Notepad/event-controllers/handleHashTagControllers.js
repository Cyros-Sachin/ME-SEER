const handleHashTagControllers = (setIsHashTagOpen, isHashTagOpen) => {
  setIsHashTagOpen(!isHashTagOpen);
};

export default handleHashTagControllers;
