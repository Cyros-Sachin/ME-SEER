// handleHeaderClicked.js

const handleHeaderClicked = (setIsHeaderClicked) => {
  setIsHeaderClicked(true);
};

export default handleHeaderClicked;
