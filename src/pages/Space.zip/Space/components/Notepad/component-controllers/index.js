import SpeechToText from "../../SpeechToText/speech-to-text";
import NotepadItem from "../../NotepadItem/notepad-item";
import BasicBlock from "../../BasicBlock/basic-block";

export default {
  SpeechToText,
  NotepadItem,
  BasicBlock,
};
