import search from "../assets/search.png";

const assetController = {
  search,
};

export default assetController;
