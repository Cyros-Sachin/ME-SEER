import emptyTodos from "../../../assets/Empty-Todos/empty-todo.PNG";

const assetController = {
  emptyTodos,
};

export default assetController;
