import microphone from "../assets/Microphone.png";
import nomicrophone from "../assets/MicrophoneSlash.png";

const assetController = {
  microphone,
  nomicrophone,
};

export default assetController;
