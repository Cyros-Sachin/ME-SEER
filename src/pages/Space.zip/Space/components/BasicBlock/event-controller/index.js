import handleNewItem from "./handleNewItem";

const eventController = {
  handleNewItem,
};

export default eventController;
