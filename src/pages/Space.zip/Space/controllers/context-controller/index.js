// bridging needed
import { NotepadProvider } from "../../components/BasicBlock/contexts/notepad-block-context";

const contextController = {
  NotepadProvider,
};

export default contextController;
